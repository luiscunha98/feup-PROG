#include "test.hpp"

TEST(test, group_1) {
    svg_test("group_1");
}
TEST(test, group_2) {
    svg_test("group_2");
}
TEST(test, group_3) {
    svg_test("group_3");
}
TEST(test, group_4) {
    svg_test("group_4");
}
TEST(test, group_5) {
    svg_test("group_5");
}
TEST(test, group_6) {
    svg_test("group_6");
}
