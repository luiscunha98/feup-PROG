#include "test.hpp"

TEST(test, polyline_1) {
    svg_test("polyline_1");
}
TEST(test, polyline_2) {
    svg_test("polyline_2");
}
TEST(test, polyline_3) {
    svg_test("polyline_3");
}
TEST(test, line_1) {
    svg_test("line_1");
}
TEST(test, line_2) {
    svg_test("line_2");
}
TEST(test, batman_2) {
    svg_test("batman_2");
}

