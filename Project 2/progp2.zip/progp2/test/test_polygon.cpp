#include "test.hpp"

TEST(test, polygon_1) {
    svg_test("polygon_1");
}
TEST(test, polygon_2) {
    svg_test("polygon_2");
}
TEST(test, rect_1) {
    svg_test("rect_1");
}
TEST(test, rect_2) {
    svg_test("rect_2");
}
TEST(test, rect_3) {
    svg_test("rect_3");
}
TEST(test, batman) {
    svg_test("batman");
}
TEST(test, lion) {
    svg_test("lion");
}
