#include "test.hpp"

TEST(test, ellipse_1) {
    svg_test("ellipse_1");
}
TEST(test, ellipse_2) {
    svg_test("ellipse_2");
}
TEST(test, circle_1) {
    svg_test("circle_1");
}
TEST(test, circle_2) {
    svg_test("circle_2");
}
