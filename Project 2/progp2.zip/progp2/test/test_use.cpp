#include "test.hpp"

TEST(test, use_1) {
    svg_test("use_1");
}
TEST(test, use_2) {
    svg_test("use_2");
}
TEST(test, use_3) {
    svg_test("use_3");
}
TEST(test, use_4) {
    svg_test("use_4");
}
TEST(test, use_5) {
    svg_test("use_5");
}
TEST(test, use_6) {
    svg_test("use_6");
}
