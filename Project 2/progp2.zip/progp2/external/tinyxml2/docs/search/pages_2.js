var searchData=
[
  ['parse_20an_20xml_20from_20char_20buffer_284',['Parse an XML from char buffer',['../_example_2.html',1,'']]]
];
