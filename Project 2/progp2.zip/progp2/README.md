
# Trabalho de programação

## Grupo

Luís Filipe Pinto Cunha - up201709375

Bruno Filipe Ferreira de Almeida - up201707297
## Tarefas realizadas

Indique aqui as tarefas que conseguiu realizar e quais não. 


