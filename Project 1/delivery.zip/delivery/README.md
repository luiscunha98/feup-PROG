
# Trabalho de programação

## Grupo
Bruno Filipe Ferreira de Almeida 201707297


## Tarefas realizadas

->rgb/image.cpp	completado todo o codigo.

->rgb/color.cpp	completado todo o codigo.

->rgb/script.cpp completado todo o codigo.

